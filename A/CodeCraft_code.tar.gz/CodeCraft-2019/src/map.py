#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
from model import *
def Graph(Cross_count, Road_count, Road_isDuplex, Road_roadFrom, Road_roadTo, Road_length, Road_id):
        #对角矩阵，对角取0，设置每两个点间的距离
        road_road_Length = np.zeros([Cross_count, Cross_count]) + 99999 - 99999 * np.eye(Cross_count)
        cross_road = np.zeros([Cross_count, Cross_count])#36*36的每个起点到终点的路号，等于路径图

        for i in range(Road_count):
            if Road_isDuplex[i] == 1:
                road_road_Length[Road_roadFrom[i]][Road_roadTo[i]] = road_road_Length[Road_roadTo[i]][Road_roadFrom[i]] = Road_length[i]
                cross_road[Road_roadFrom[i]][Road_roadTo[i]] = cross_road[Road_roadTo[i]][Road_roadFrom[i]] = Road_id[i]
            else:
                road_road_Length[Road_roadFrom[i]][Road_roadTo[i]] = Road_length[i]
                cross_road[Road_roadFrom[i]][Road_roadTo[i]] = Road_id[i]
        #road_loss = road_road_Length
        return road_road_Length, cross_road#, road_loss


def Dijkstra(origin, destination, road_road_length):
    dead = 99999 #死路
    path_array = []
    temp_array = []
    path_array.extend(road_road_length[origin])
    temp_array.extend(road_road_length[origin])
    temp_array[origin] = dead
    already_traversal = [origin]
    path_parent = [origin] * Cross.count #cross*cross
    i = origin
    while (i != destination):
        i = temp_array.index(min(temp_array))#最短的一条路的cross_id
        temp_array[i] = dead
        path = []
        path.append(i)#记录走过的路
        k = i
        while (path_parent[k] != origin):
            path.append(path_parent[k])
            k = path_parent[k]
        path.append(origin)
        path.reverse()
        already_traversal.append(i)
        for j in range(Cross.count):
            if j not in already_traversal:
                if (path_array[i] + road_road_length[i][j]) < path_array[j]:
                    path_array[j] = temp_array[j] = path_array[i] + road_road_length[i][j]
                    path_parent[j] = i
    return path