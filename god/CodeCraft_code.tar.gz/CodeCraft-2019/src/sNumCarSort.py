#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from map import *

def all_car_path(map_array, map_road_array):
    """
    每个时间安排固定的车辆发车
    """

    path_road = []
    for i in range(Car.count):
        path = Dijkstra(Car.origin[i] - 1, Car.destination[i] - 1, map_array)
        path_center = []
        for j in range(len(path) - 1):
            path_center.append(int(map_road_array[path[j]][path[j + 1]]))#把路口点cross转化成road id
        time = i // 15 #每个时间出发数量限制11-2 1006 /12-2 928/15-2 758 /25-2 溢出 纯粹寻找边际
        path_road.append(tuple([Car.id[i], max(Car.startTime[i], time)] + path_center))
    return path_road
